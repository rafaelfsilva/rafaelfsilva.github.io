#include <iostream>
#include <vector>


/**
 * Linear search.
 * @param mylist A vector of integers
 * @param k Element to be found
 * @param return_iter Whether to return the element index or number of iterations
 * @return The element index or number of iterations
 */
int search(const std::vector<int> mylist, const int k, const bool return_iter) {
    int i;
    int iter = 0;
    for (i = 0; i < mylist.size(); i++) {
        iter++;
        if (mylist[i] == k) {
            if (return_iter) {
                return iter;
            }
            return i;
        }
    }
    return -1;
}

/**
 * Binary search.
 * @param mylist An ordered vector of integers
 * @param k Element to be found
 * @param start Start position (index) for the search
 * @param end End position (index) for the search
 * @param return_iter Whether to return the element index or number of iterations
 * @return The element index or number of iterations
 */
int bsearch(const std::vector<int> mylist, const int k, int start, int end, const bool return_iter) {
    int i;
    int iter = 0;
    // range is empty when start == end
    while (start < end) {
        iter++;
        int mid = (start + end) / 2;

        if (k == mylist[mid]) {
            if (return_iter) {
                return iter;
            }
            return mid;

        } else if (k < mylist[mid]) {
            end = mid;

        } else {
            start = mid + 1;
        }
    }
    return -1;
}


/**
 * Interpolation search.
 * @param mylist An ordered vector of integers
 * @param k Element to be found
 * @param start Start position (index) for the search
 * @param end End position (index) for the search
 * @param return_iter Whether to return the element index or number of iterations
 * @return
 */
int interp_search(const std::vector<int> mylist, const int k, int start, int end, const bool return_iter) {
    int iter = 0;
    // range is empty when start > end
    while (start <= end) {
        iter++;
        int loc = start + ((k - mylist[start]) * (end - start)) / (mylist[end - 1] - mylist[start]);

        if (k == mylist[loc]) {
            if (return_iter) {
                return iter;
            }
            return loc;

        } else if (k < mylist[loc]) {
            start = loc - 1;

        } else {
            start = loc + 1;
        }
    }
    return -1;
}


/**
 * Compares different search methods, printing the index of the element and the number of iterations.
 * @param list An ordered vector of integers
 * @param k Element to be found
 * @param interp Whether to run interporlation search
 */
void compare_search(const std::vector<int> list, const int k, const bool interp) {

    int index = search(list, k, false);
    int iterations = search(list, k, true);
    std::cout << "  [Linear Search] Index: " << index << " - Iterations: " << iterations << std::endl;

    index = bsearch(list, k, 0, list.size(), false);
    iterations = bsearch(list, k, 0, list.size(), true);
    std::cout << "  [Binary Search] Index: " << index << " - Iterations: " << iterations << std::endl;

    if (interp) {
        index = interp_search(list, k, 0, list.size(), false);
        iterations = interp_search(list, k, 0, list.size(), true);
        std::cout << "  [Interp Search] Index: " << index << " - Iterations: " << iterations << std::endl;
    }

    std::cout << std::endl;
}

/**
 * Struct to order list in decreasing order.
 */
struct greater {
    template<class T>
    bool operator()(T const &a, T const &b) const { return a > b; } // Functor
};

/**
 * Main program.
 * @return Program exit code
 */
int main() {
    std::vector<int> list;

    for (int i = 0; i < 1000; i++) {
        list.push_back(i + 1);
    }

    // Sorted list
    std::cout << "A few comparisons:" << std::endl;
    compare_search(list, 501, false);
    compare_search(list, 250, false);
    compare_search(list, 999, false);

    // Unsorted list
    std::cout << "Unsorted (unordered) list:" << std::endl;
    std::sort(list.begin(), list.end(), greater()); // C++ STL sort algorithm

    compare_search(list, 501, false);
    compare_search(list, 250, false);
    compare_search(list, 999, false);

    // Random list: a uniform distribution of 100 random numbers between [0 and 999]
    std::vector<int> random_list;

    // initialize random seed:
    srand(time(NULL));

    int min = 0;
    int max = 999;
    for (int i = 0; i < 100; i++) {
        int randNum = rand() % (max - min + 1) + min; // generates a random int between [0 and 999]
        if (std::find(random_list.begin(), random_list.end(), randNum) == random_list.end()) {
            random_list.push_back(randNum);
        }
    }
    std::sort(random_list.begin(), random_list.end()); // C++ STL sort algorithm

    std::cout << "Random List: Min=" << random_list[0] << " - Max=" << random_list[random_list.size() - 1] << std::endl;
    compare_search(random_list, random_list[55], true);
    compare_search(random_list, random_list[10], true);
    compare_search(random_list, random_list[82], true);
}