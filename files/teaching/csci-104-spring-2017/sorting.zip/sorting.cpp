#include <iostream>
#include <vector>

/**
 * Prints the vector elements.
 * @param mylist
 */
void print(std::vector<int> mylist) {
    std::cout << "  [ ";
    for (std::vector<int>::iterator it = mylist.begin(); it != mylist.end(); ++it) {
        std::cout << *it << " ";
    }
    std::cout << "]" << std::endl;
}

/**
 * Swap two integer values.
 * @param v1 Integer value
 * @param v2 Integer value
 */
void swap(int &v1, int &v2) {
    int temp = v1;
    v1 = v2;
    v2 = temp;
}

/**
 * Bubble sort algorithm.
 * @param mylist List of integer values
 */
void bubble_sort(std::vector<int> mylist) {

    for (int i = mylist.size() - 1; i > 0; i--) {
        for (int j = 0; j < i; j++) {
            if (mylist[j] > mylist[j + 1]) {
                swap(mylist[j], mylist[j + 1]);
            }
        }
        print(mylist); // for illustrative purpose
    }
}

/**
 * Selection sort algorithm.
 * @param mylist List of integer values
 */
void selection_sort(std::vector<int> mylist) {
    for (int i = 0; i < mylist.size() - 1; i++) {
        int min = i;
        for (int j = i + 1; j < mylist.size(); j++) {
            if (mylist[j] < mylist[min]) {
                min = j;
            }
        }
        swap(mylist[i], mylist[min]);
        print(mylist);
    }
}

/**
 * Insertion sort algorithm.
 * @param mylist List of integer values
 */
void insertion_sort(std::vector<int> mylist) {
    for (int i = 1; i < mylist.size(); i++) {
        int val = mylist[i];
        int hole = i;
        while (hole > 0 && val < mylist[hole - 1]) {
            mylist[hole] = mylist[hole - 1];
            hole--;
        }
        mylist[hole] = val;
        print(mylist);
    }
}

/**
 * Partition algorithm. Used by Quick Sort.
 * @param mylist
 * @param start
 * @param end
 * @param p
 * @return
 */
int partition(std::vector<int> &mylist, int start, int end, int p) {

    int pivot = mylist[p];
    swap(mylist[p], mylist[end]);  // move pivot out of the way for now

    int left = start;
    int right = end - 1;

    while (left < right) {
        while (mylist[left] <= pivot && left < right) {
            left++;
        }
        while (mylist[right] >= pivot && left < right) {
            right--;
        }
        if (left < right) {
            swap(mylist[left], mylist[right]);
        }
    }
    if (mylist[right] > mylist[end]) {    // put pivot in
        swap(mylist[right], mylist[end]); // correct place
        return right;
    }
    return end;
}


/**
 * Quick sort algorithm.
 * @param mylist
 * @param start
 * @param end
 */
void quick_sort(std::vector<int> &mylist, int start, int end) {
    // base case – list has 1 or less items
    if (start >= end) {
        return;
    }

    int p = (start + end) / 2; // could be a rand value

    // partition
    std::cout << "    Pivot: " << mylist[p] << std::endl;
    int loc = partition(mylist, start, end, p);
    print(mylist);


    // recurse on both sides
    quick_sort(mylist, start, loc - 1);
    quick_sort(mylist, loc + 1, end);
}


int main() {
    std::vector<int> mylist = {7, 3, 8, 6, 5, 1};

    std::cout << "Bubble Sort:" << std::endl;
    bubble_sort(mylist);
    std::cout << std::endl;

    std::cout << "Selection Sort:" << std::endl;
    selection_sort(mylist);
    std::cout << std::endl;

    std::cout << "Insertion Sort:" << std::endl;
    insertion_sort(mylist);
    std::cout << std::endl;

    std::cout << "Quick Sort:" << std::endl;
    mylist = {7, 5, 3, 6, 8, 1};
    quick_sort(mylist, 0, mylist.size() - 1);
    std::cout << std::endl;

    return 0;
}
