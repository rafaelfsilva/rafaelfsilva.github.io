
#include <iostream>
#include <queue>
#include <string>

class Item {
public:
	int score;
	std::string name;

	Item(int s, std::string n) {
		score = s;
		name = n;
	}

	bool operator>(const Item &rhs) const {
		if (rhs.score > this->score) {
			return true;
		}
		return false;
	}

	bool operator<(const Item &rhs) const {
		if (rhs.score < this->score) {
			return true;
		}
		return false;
	}
};

int main() {
	// First template parameter should be type of element stored
	// Second template parameter should be the container class you want
	//   to use to store the items (usually vector<type_of_elem>)
	// Third template parameters should be comparison functor object/class
	//   that will define the order from first to last in the container
	std::priority_queue<Item, std::vector<Item>, std::greater<Item> > mypq;

	Item i1(25, "Bill");
	mypq.push(i1);

	Item i2(5, "Jane");
	mypq.push(i2);

	Item i3(10, "Charlie");
	mypq.push(i3);

	std::cout << "Popping out elements (greater):" << std::endl;
	while (!mypq.empty()) {
		std::cout << "  " << mypq.top().name << std::endl;
		mypq.pop();
	}
	std::cout << std::endl;


	std::priority_queue<Item, std::vector<Item>, std::less<Item> > mypq_less;
	mypq_less.push(i1);
	mypq_less.push(i2);
	mypq_less.push(i3);

	std::cout << "Popping out elements (less):" << std::endl;
	while (!mypq_less.empty()) {
		std::cout << "  " << mypq_less.top().name << std::endl;
		mypq_less.pop();
	}
}
