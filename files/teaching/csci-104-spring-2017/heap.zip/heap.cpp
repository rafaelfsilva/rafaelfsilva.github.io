#include <iostream>
#include <vector>
#include <cmath>

template<typename T>
class MinHeap {
public:
	MinHeap();

	void push(const T &item);

	T &top();

	void pop();

	bool empty() const;

	void print() const;

private:
	void heapify(int idx);

	void trickleUp(int idx);

	void swap(int parent, int child);

	std::vector<T> items_;
};

template<typename T>
MinHeap<T>::MinHeap() {
	items_.push_back(-1);
}

template<typename T>
void MinHeap<T>::push(const T &item) {

	items_.push_back(item);
	trickleUp((int) items_.size() - 1);
}

template<typename T>
T &MinHeap<T>::top() {

	if (empty()) {
		throw (std::out_of_range("Array is empty!"));
	}
	return items_[1];
}

template<typename T>
void MinHeap<T>::pop() {

	items_[1] = items_.back();
	items_.pop_back();
	heapify(1); // a.k.a. trickleDown()
}

template<typename T>
void MinHeap<T>::heapify(int idx) {

	int length = (int) items_.size();
	int left_child = 2 * idx;
	int right_child = 2 * idx + 1;

	if (left_child >= length) {
		return; // index is a leaf
	}

	int smaller_child = left_child; // start w/ left

	if (right_child < length && items_[right_child] < items_[left_child]) {
		smaller_child = right_child;
	}

	if (items_[idx] > items_[smaller_child]) {
		swap(idx, smaller_child);
		heapify(smaller_child);
	}
}

template<typename T>
void MinHeap<T>::trickleUp(int idx) {

	if (idx == 0) {
		return;
	}

	int parent = idx / 2;

	if (items_[idx] < items_[parent]) {
		swap(parent, idx);
		trickleUp(parent);
	}
}

template<typename T>
void MinHeap<T>::swap(int parent, int child) {

	int temp = items_[parent];
	items_[parent] = items_[child];
	items_[child] = temp;
}

template<typename T>
void MinHeap<T>::print() const {
	int level = 1;
	int count = 0;

	for (typename std::vector<T>::const_iterator i = items_.begin() + 1; i != items_.end(); ++i, ++count) {
		if (count == level) {
			std::cout << std::endl;
			if (level == 1) {
				level = 2;
			} else {
				level += 2;
			}
			count = 0;
		}
		std::cout << *i << " ";
	}
	std::cout << std::endl;
	std::cout << std::endl;
}

template<typename T>
bool MinHeap<T>::empty() const {
	return items_.size() <= 1;
}


int main() {

	MinHeap<int> min_heap;
	min_heap.push(7);
	min_heap.push(18);
	min_heap.push(9);
	min_heap.push(19);
	min_heap.push(35);
	min_heap.push(14);
	min_heap.push(10);
	min_heap.push(28);
	min_heap.push(39);
	min_heap.push(36);
	min_heap.print();

	// adding 11
	min_heap.push(11);
	min_heap.print();

	// adding 40
	min_heap.push(40);
	min_heap.print();

	// removing
	min_heap.pop();
	min_heap.print();

	// removing
	min_heap.pop();
	min_heap.print();


	// heap sort - O(n * log n)
	while (!min_heap.empty()) {
		std::cout << min_heap.top() << " ";
		min_heap.pop();
		std::cout << " ";
	}
	std::cout << std::endl;
}