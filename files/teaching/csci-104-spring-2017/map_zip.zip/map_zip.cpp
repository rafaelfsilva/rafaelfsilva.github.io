#include <iostream>
#include <fstream>
#include <vector>
#include <map>
// needed for built-in sort
#include <algorithm>

using namespace std;


bool zip_comp(const pair<int, int> &lhs, const pair<int, int> &rhs) {
    return lhs.first < rhs.first;
}

bool occ_comp(const pair<int, int> &lhs, const pair<int, int> &rhs) {
    return lhs.second < rhs.second;
}

int main(int argc, char *argv[]) {

    if (argc < 2) {
        cerr << "Usage: ./map_zip zipcode_filename" << endl;
        return -1;
    }

    ifstream zipfile(argv[1]);

    if (!zipfile.good()) {
        cerr << "Unable to open file" << argv[1] << endl;
    }

    vector<int> all_zips;

    // reading zip codes file
    int zipCode;
    zipfile >> zipCode;
    while (!zipfile.fail()) {
        all_zips.push_back(zipCode);
        zipfile >> zipCode;
    }
    zipfile.close();

    // Key = zipcode, Value = Num. of Occurrences
    map<int, int> zipMap;


    // Iterate through all the zip codes in 'all_zips' and
    // create a map of zipcode to number of occurrences
    vector<int>::iterator it;
    for (it = all_zips.begin(); it != all_zips.end(); it++) {

        // Check whether the map already has the key
        if (zipMap.find(*it) != zipMap.end()) {
            zipMap[*it]++;

        } else {
            // Add a new key to the map
            zipMap[*it] = 1;
        }

        // Optionally this implementation can be simplified to the line below,
        // since this is a map of ints
//        zipMap[*it]++;
    }


    // Iterators to Maps return the key as '->first' and the value as '->second'
    cout << "Zip code, occurrence table" << endl;
    for (map<int, int>::iterator it = zipMap.begin(); it != zipMap.end(); ++it) {
        cout << it->first << " occurs " << it->second << " times" << endl;
    }
    cout << endl;



    // Using 'count' from 'algorithm'
    int myCount = count(all_zips.begin(), all_zips.end(), 90018);
    cout << "90018 occurs " << myCount << " times" << endl;
    cout << endl;

    // Sorting
    sort(all_zips.begin(), all_zips.end());
    for (it = all_zips.begin(); it != all_zips.end(); it++) {
        cout << *it << endl;
    }
    cout << endl;


    // Sorting Maps by Keys
    vector<pair<int, int>> items;
    copy(zipMap.begin(), zipMap.end(), back_inserter(items)); // copy the map into a vector

    sort(items.begin(), items.end(), zip_comp); // Map default sort is per key

    cout << "Zip code, occurrence table" << endl;
    for (vector<pair<int, int>>::iterator it = items.begin(); it != items.end(); ++it) {
        cout << it->first << " occurs " << it->second << " times" << endl;
    }
    cout << endl;


    sort(items.begin(), items.end(), occ_comp); // Map default sort is per key

    cout << "Zip code, occurrence table (sorted by value)" << endl;
    for (vector<pair<int, int>>::iterator it = items.begin(); it != items.end(); ++it) {
        cout << it->first << " occurs " << it->second << " times" << endl;
    }
    cout << endl;


    return 0;
}
