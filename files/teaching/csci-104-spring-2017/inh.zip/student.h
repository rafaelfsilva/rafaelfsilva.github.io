#ifndef STUDENT_H
#define STUDENT_H

#include <vector>
#include "person.h"

using namespace std;

class Student : public Person {
public:
    Student();

    Student(std::string name, int id);

    ~Student();

    void add_grade(int score);

    int get_grade(int index);

    void print_grades();

    void print();

private:
    std::vector<int> grades;
};

#endif
