#include <iostream>
#include <string>
#include "person.h"
#include "student.h"
#include "faculty.h"

using namespace std;

int main() {

    // empty objects only to analyze how constructors/destructors are invoked
    cout << "Creating empty objects" << endl;
    Person p;
//    Student s;
    cout << endl;


    cout << "Creating Person object" << endl;
    Person p1("Mark", 10);
    cout << endl;

    cout << "Creating Student object" << endl;
    Student s1("Tommy", 90);
    cout << endl;


    cout << "Printing objects contents" << endl;
    cout << "  Person 1: " << p1.get_name() << " id: " << p1.get_id() << endl;
    cout << "  Student 1: " << s1.get_name() << " id: " << s1.get_id() << endl;
    cout << endl;


    // setting a grade
    s1.add_grade(100);

    cout << "Printing a student grade" << endl;
    cout << "  Student 1: " << s1.get_name() << " id: " << s1.get_id() << endl;
    cout << "  Student 1 grade: " << s1.get_grade(0) << endl;
    cout << endl;


    // adding more grades
    s1.add_grade(90);
    s1.add_grade(55);
    s1.add_grade(87);

    cout << "Printing a student grade" << endl;
    cout << "  Student 1: " << s1.get_name() << " id: " << s1.get_id() << endl;
    s1.print_grades();
    cout << endl;


    // creating a faculty
    cout << "Creating Faculty object" << endl;
    Faculty f1("Gaurav", 100, true);
    cout << endl;

    cout << "Printing faculty" << endl;
//    cout << "  Faculty 1: " << f1.get_name() << " id: " << f1.get_id() << endl; // inaccessible (private)
    cout << "  Tenure: " << f1.get_tenure() << endl;
    cout << endl;


    // creating another student
    cout << "Creating another Student object" << endl;
    Student s2("John", 2);
    cout << endl;

    // creating another faculty
    cout << "Creating another Faculty object" << endl;
    Faculty f2("Trojan", 200, false);
    cout << endl;


    cout << "Printing different objects" << endl;
    p1.print();
    s1.print();
    s2.print();
    f1.print();
    f2.print();
    cout << endl;

    cout << "Quitting the program" << endl;
    return 0;
}
