#ifndef PERSON_H
#define PERSON_H

#include <string>

class Person {
public:
    // accessible to anyone
    Person();

    Person(std::string name, int id);

    ~Person();

    std::string get_name();

    int get_id();

    void print();

private:
    // inaccessible to derived classes
//    std::string name;
    int id;

protected:
//    // Private to anyone not inheriting from the base, and derived classes can access directly
    std::string name;
};

#endif
