#ifndef INH_FACULTY_H
#define INH_FACULTY_H

#include <vector>
#include "person.h"

using namespace std;

class Faculty : private Person {
// public & protected base class members are private to clients (not accessible to the outside world)

public:
    Faculty();

    Faculty(string name, int id, bool tenure);

    ~Faculty();

    bool get_tenure();

    void print();

private:
    bool tenure;
};

#endif //INH_FACULTY_H
