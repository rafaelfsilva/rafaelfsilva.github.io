#include <iostream>
#include <vector>
#include <string>
#include "student.h"

using namespace std;

Student::Student() {
    cout << "  Student()" << endl;
}

// regular 2-args constructor
//Student::Student(string name, int id) {
//    cout << "  Student(\"" << name << "\", " << id << ")" << endl;
////    this->name_ = name;
////    this->id_ = id;
//    // does not call the parent class 2-args constructor, instead calls Person()
//}

// initializer format to call 2-args Person's constructor
Student::Student(string name, int id) : Person(name, id) {
    cout << "  Student(\"" << name << "\", " << id << ")" << endl;
}

Student::~Student() {
    cout << "  ~Student()" << endl;
}

void Student::add_grade(int score) {
    grades.push_back(score);
}

int Student::get_grade(int index) {
    return grades[index];
}

void Student::print_grades() {
    cout << "  Grades for " << name << ":" << endl;
    cout << "    ";
    for (size_t i = 0; i < grades.size(); i++) {
        cout << grades[i] << " ";
    }
    cout << endl;
}

void Student::print() {
    if (grades.size() > 0) {
        cout << "  Name: " << name << "\tGRADE[0]: " << grades[0] << endl;
    } else {
        Person::print();
    }
}
