#include <iostream>
#include <vector>
#include <string>
#include "faculty.h"

using namespace std;

Faculty::Faculty() {
    cout << "  Faculty()" << endl;
}

// initializer format to call 2-args Person's constructor
Faculty::Faculty(string name, int id, bool tenure) : Person(name, id) {
    cout << "  Faculty(\"" << name << "\", " << id << ")" << endl;
    this->tenure = tenure;
}

Faculty::~Faculty() {
    cout << "  ~Faculty()" << endl;
}

bool Faculty::get_tenure() {
    return tenure;
}

void Faculty::print() {
    if (tenure) {
        cout << "  Name: " << name << " (Tenure) " << endl;
    } else {
        Person::print();
    }
}
