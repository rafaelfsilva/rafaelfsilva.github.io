#include <iostream>
#include <string>
#include "person.h"

using namespace std;

Person::Person() {
    cout << "  Person()" << endl;
}

// Use constructor initialization list style
Person::Person(string name, int id) : name(name), id(id) {
    cout << "  Person(\"" << name << "\", " << id << ")" << endl;

}

Person::~Person() {
    cout << "  ~Person()" << endl;

}

string Person::get_name() {
    return name;
}

int Person::get_id() {
    return id;
}

void Person::print() {
    cout << "  Name: " << name << "\tID: " << id << endl;
}