#ifndef STACK_H
#define STACK_H

#include "llist_sol.h"
#include <vector>

template<typename T>
class Stack : private LList<T> {
public:
    Stack();

    void push(const T &newval);

    T const &top() const;

    T const &get(const int loc);

private:
    std::vector<T> data;
};

template<typename T>
Stack<T>::Stack() : LList<T>() {}


// For various reasons the compiler may have difficulty
// resolving members of a templated base class


template<typename T>
void Stack<T>::push(const T &newval) {

//    insert(size_, newval); // may not compile

    LList<T>::insert(LList<T>::size_, newval); // works

    this->insert(this->size_, newval);     // works
}

// When accessing members of a templated base class
// provide the full scope or precede the member with this->

template<typename T>
T const &Stack<T>::top() const {

//    if (head_) { // may not work
//        return head_->val;
//    }

    if (LList<T>::head_) { // works
        return LList<T>::head_->val;
    }

    if (this->head_) { // works
        return this->head_->val;
    }
}

template<typename T>
T const &Stack<T>::get(const int loc) {

    // For various reasons the compiler may have difficulty
    // resolving **nested** types of a templated class
    // whose template argument is still generic
//    std::vector<T>::iterator it = data.end(); // won't compile

    // Precede the nested type with the keyword 'typename'
    typename std::vector<T>::iterator it = data.end();

    return *(it - 1);
}

#endif //STACK_H