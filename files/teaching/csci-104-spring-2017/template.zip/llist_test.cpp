#include <iostream>
#include "llist_sol.h"
#include "stack.h"

using namespace std;

// Template typename or class? See the discussion in the link below:
// https://web.archive.org/web/20060619131004/http://blogs.msdn.com/slippman/archive/2004/08/11/212768.aspx


int main() {

    // declare a LList of type int
    LList<int> lst;

    try {
        cout << "Inserting data into list" << endl;
        for (int i = 0; i < 5; i++) {
            lst.insert(i, i);
        }

        // this should generate an exception
        cout << "Trying to get element at position 10" << endl;
        cout << lst.get(10) << endl;

        // this should also generate an exception
        cout << "Inserting at position 7" << endl;
        lst.insert(7, 7);

        cout << "Pop first 10 elements from the list" << endl;
        for (int i = 0; i < 10; i++) {
            lst.pop(0);
        }

    } catch (invalid_argument &e) {
        cerr << "Catch exception and do something: " << e.what() << endl;
        cerr << "Max List size: " << lst.size() << endl;
        cerr << endl;
    }

    return 0;
}
