#include <iostream>
#include <vector>

void merge(std::vector<int> &mylist, std::vector<int> &output, int s1, int e1, int s2, int e2) {

    int index = s1;
    while (s1 <= e1 && s2 <= e2) {
        if (mylist[s1] < mylist[s2]) {
            output[index++] = mylist[s1++];
        } else {
            output[index++] = mylist[s2++];
        }
    }
    while (s1 <= e1) {
        output[index++] = mylist[s1++];
    }
    while (s2 <= e2) {
        output[index++] = mylist[s2++];
    }
}

void msort(std::vector<int> &mylist, std::vector<int> &output, int start, int end) {

    // base case
    if (start >= end) {
        return;
    }

    // recursive calls
    int mid = (start + end) / 2;

    msort(mylist, output, start, mid);
    msort(mylist, output, mid + 1, end);

    // merge
    merge(mylist, output, start, mid, mid + 1, end);
    mylist = output;
}

void merge_sort(std::vector<int> &mylist) {

    std::vector<int> other(mylist);  // copy of array

    // use other as the source array, mylist as the output array
    msort(other, mylist, 0, other.size() - 1);
}

void print(std::vector<int> input) {
    for (std::vector<int>::iterator it = input.begin(); it != input.end(); ++it) {
        std::cout << *it << " ";
    }
    std::cout << std::endl;
}

int main() {

    std::vector<int> result;

    std::vector<int> mylist = {7, 3, 8, 6, 5, 1, 10, 12, 2};
    merge_sort(mylist);
    print(mylist);

    return 0;

}