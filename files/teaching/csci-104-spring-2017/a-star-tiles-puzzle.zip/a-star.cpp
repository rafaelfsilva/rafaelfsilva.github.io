/**
 *  8-tile game - A* algorithm
 *
 *  Solution board:
 *  1 2 3
 *  4 5 6
 *  7 8
 *
 */

#include <iostream>
#include <vector>
#include <random>
#include <queue>

static const int BOARD_SIZE = 3;
static const int SOLUTION[9][3] = {
		// solution for a board size 3x3
		{0, 0},
		{0, 0}, // 1
		{0, 1}, // 2
		{0, 2}, // 3
		{1, 0}, // 4
		{1, 1}, // 5
		{1, 2}, // 6
		{2, 0}, // 7
		{2, 1}  // 8
};

class State {
public:
	/**
	 * State class constructor.
	 */
	State(int **board, int step, State *predecessor) : board_(board), g_(step), predecessor_(predecessor) {
		h_ = heuristic();
		f_ = g_ + h_;
		instance_ = this;
	}

	State *getPredecessor() {
		return predecessor_;
	}

	/**
 	* Print the board.
 	*/
	void printBoard() {
		for (int i = 0; i < BOARD_SIZE; i++) {
			for (int j = 0; j < BOARD_SIZE; j++) {
				std::cout << board_[i][j] << " ";
			}
			std::cout << std::endl;
		}
	}

	/**
	 * Generate successors (moves from top, bottom, left, and right)
	 */
	std::vector<State> generateSuccessors() {
		std::vector<State> successors;

		// move from top
		if (empty_x_idx_ > 0) {
			int **new_board = copyBoard();
			new_board[empty_x_idx_][empty_y_idx_] = new_board[empty_x_idx_ - 1][empty_y_idx_];
			new_board[empty_x_idx_ - 1][empty_y_idx_] = 0;
			State *s = new State(new_board, g_ + 1, instance_);
			successors.push_back(*s);
		}

		// move from bottom
		if (empty_x_idx_ < BOARD_SIZE - 1) {
			int **new_board = copyBoard();
			new_board[empty_x_idx_][empty_y_idx_] = new_board[empty_x_idx_ + 1][empty_y_idx_];
			new_board[empty_x_idx_ + 1][empty_y_idx_] = 0;
			State *s = new State(new_board, g_ + 1, instance_);
			successors.push_back(*s);
		}

		// move from left
		if (empty_y_idx_ > 0) {
			int **new_board = copyBoard();
			new_board[empty_x_idx_][empty_y_idx_] = new_board[empty_x_idx_][empty_y_idx_ - 1];
			new_board[empty_x_idx_][empty_y_idx_ - 1] = 0;
			State *s = new State(new_board, g_ + 1, instance_);
			successors.push_back(*s);
		}

		// move from right
		if (empty_y_idx_ < BOARD_SIZE - 1) {
			int **new_board = copyBoard();
			new_board[empty_x_idx_][empty_y_idx_] = new_board[empty_x_idx_][empty_y_idx_ + 1];
			new_board[empty_x_idx_][empty_y_idx_ + 1] = 0;
			State *s = new State(new_board, g_ + 1, instance_);
			successors.push_back(*s);
		}

		return successors;
	}

	void update(const State &rhs) {
		if (rhs.f_ < this->f_) {
			this->f_ = rhs.f_;
			this->g_ = rhs.g_;
			this->h_ = rhs.h_;
			this->predecessor_ = rhs.predecessor_;
		}
	}

	bool isGoalState() {
		return h_ == 0;
	}

	bool operator<(const State &rhs) const {
		if (this->f_ > rhs.f_) {
			return true;
		} else if (this->f_ == rhs.f_ && this->g_ < rhs.g_) {
			return true;
		}
		return false;
	}

	bool operator==(const State &rhs) const {
		for (int i = 0; i < BOARD_SIZE; i++) {
			for (int j = 0; j < BOARD_SIZE; j++) {
				if (board_[i][j] != rhs.board_[i][j]) {
					return false;
				}
			}
		}
		return true;
	}

private:
	// Data members
	int **board_;
	int g_, h_, f_, empty_x_idx_, empty_y_idx_;
	State *predecessor_;
	State *instance_;

	// Functions
	int heuristic() {
		int sum_dist = 0;

		// compute manhattan distance to solution
		for (int i = 0; i < BOARD_SIZE; i++) {
			for (int j = 0; j < BOARD_SIZE; j++) {
				int value = board_[i][j];
				if (value == 0) {
					empty_x_idx_ = i;
					empty_y_idx_ = j;
				} else {
					sum_dist += std::abs(SOLUTION[value][0] - i);
					sum_dist += std::abs(SOLUTION[value][1] - j);
				}
			}
		}
		return sum_dist;
	}

	int **copyBoard() {
		int **new_board;
		new_board = new int *[BOARD_SIZE];
		for (int i = 0; i < BOARD_SIZE; i++) {
			new_board[i] = new int[BOARD_SIZE];
			std::copy(board_[i], board_[i] + BOARD_SIZE, new_board[i]);
		}
		return new_board;
	}

};

class Game {

public:
	/**
	 * Initialize a board with tiles in a random position.
	 * Generates a solvable puzzle.
	 */
	int **initialize() {

		int **board;

		while (true) {
			int linear[BOARD_SIZE * BOARD_SIZE];
			int linear_idx = 0;

			board = new int *[BOARD_SIZE];
			// zero value denotes the empty space in the board
			std::vector<int> values = {0, 1, 2, 3, 4, 5, 6, 7, 8};
			for (int i = 0; i < BOARD_SIZE; i++) {
				board[i] = new int[BOARD_SIZE];
				for (int j = 0; j < BOARD_SIZE; j++) {
					int index = 0 + (rand() % values.size());
					board[i][j] = values[index];
					linear[linear_idx++] = values[index];
					values.erase(values.begin() + index);
				}
			}

			// check whether the board is solvable
			int inversions = 0;
			for (int i = 0; i < BOARD_SIZE * BOARD_SIZE; i++) {
				if (linear[i] != 0) {
					for (int j = i + 1; j < BOARD_SIZE * BOARD_SIZE; j++) {
						if (linear[j] != 0 and linear[j] > linear[i]) {
							inversions++;
						}
					}
				}
			}
			if (inversions % 2 == 0) {
				// the board is solvable
				break;
			}
		}
		return board;
	}

	/**
	 * Solve the puzzle.
	 */
	void solve(int **board) {
		// add start state to open_list
		State *start_state = new State(board, 0, NULL);
		open_list_.push(*start_state);

		std::cout << "Initial Board:" << std::endl;
		start_state->printBoard();
		std::cout << std::endl;

		State *solution;

		while (!open_list_.empty()) {
			// get first state from the open list
			State s = open_list_.top();
			open_list_.pop();
			closed_list_.push_back(s);

			if (s.isGoalState()) {
				solution = &s;
				std::cout << "Found a Solution!" << std::endl;
				break;
			}
			// generate list of successor states
			std::vector<State> successors = s.generateSuccessors();

			std::vector<State> temp_list;
			while (!open_list_.empty()) {
				temp_list.push_back(open_list_.top());
				open_list_.pop();
			}

			// add successors to open list or update f-values
			for (auto its = successors.begin(); its != successors.end(); its++) {
				bool inClosedList = false;
				for (auto it = closed_list_.begin(); it != closed_list_.end(); it++) {
					if ((*it) == (*its)) {
						inClosedList = true;
						break;
					}
				}
				if (!inClosedList) {
					// check whether state is already in open list
					bool inOpenList = false;
					for (auto it = temp_list.begin(); it != temp_list.end(); it++) {
						if ((*it) == (*its)) {
							// update state values if 'f' value is smaller
							(*it).update((*its));
							inOpenList = true;
							break;
						}
					}
					if (!inOpenList) {
						// new state
						temp_list.push_back((*its));
					}
				}
			}
			for (auto it = temp_list.begin(); it != temp_list.end(); it++) {
				open_list_.push((*it));
			}
		}

		// Build solution vector
		State *temp = solution;
		std::vector<State> solution_vector;
		while (temp) {
			solution_vector.push_back(*temp);
			temp = temp->getPredecessor();
		}
		std::cout << "Number of visited states: " << closed_list_.size() << std::endl;
		std::cout << "Number of Steps: " << solution_vector.size() - 1 << std::endl;
		std::cout << std::endl;

		// Print solution step-by-step
		int step = 1;
		std::cout << "Solution:" << std::endl;
		for (auto it = solution_vector.rbegin() + 1; it != solution_vector.rend(); it++) {
			std::cout << "Step " << step++ << ":" << std::endl;
			(*it).printBoard();
			std::cout << std::endl;
		}
	}

private:
	// Data members
	std::priority_queue<State> open_list_;
	std::vector<State> closed_list_;
};

int main() {
	srand(time(0));

	Game g;
	int **board = g.initialize();
	g.solve(board);
}