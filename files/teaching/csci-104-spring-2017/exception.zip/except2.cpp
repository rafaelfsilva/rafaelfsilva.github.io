#include <iostream>
#include <fstream>
#include <string>
#include <stdexcept>

using namespace std;

void readFile(char *filename) {
    ifstream ifile;
    ifile.exceptions(ios::failbit);
    // will throw if opening fails
    ifile.open(filename);

    // Should you catch exception here
    // Or should you catch it in main()
}

int main() {

    string filename;

    do {
        cin.exceptions(ios::failbit);
        cout << "Enter a filename: ";
        try {
            cin >> filename;

            char *cstr = new char[filename.length() + 1];
            strcpy(cstr, filename.c_str());

            readFile(cstr);

            break;

        } catch (ios::failure &ex) {
            cerr << "Error: " << ex.what() << endl;
            cin.clear();
            cin.ignore(1000, '\n');
        }
    } while (1);

    cout << "End of program" << endl;
}

/** TIP: Do not use throw from a destructor.  Your code will
 * go into an inconsistent (and unpleasant) state.  Or just crash.
 **/