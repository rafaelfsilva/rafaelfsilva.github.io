#include <iostream>
#include <vector>
#include <stdexcept>
/** all stdexcept: http://www.cplusplus.com/reference/stdexcept/ **/

using namespace std;

int divide(int num, int denom) {
    if (denom == 0) {
//        throw denom;  // just throw an int
        throw invalid_argument("Div by 0");  // using stdexcept
        /** code execution stops here, after the throw **/
    }
    if (denom < 0) {
        throw domain_error("Negative denom");
    }
    return (num / denom);
}

int f1(int x) {
    return divide(x, x - 2);
    /** since f1 does not catch any exception, the exception is
     * rethrown up in the stack call.
     */
}

int main() {

    /** simple test of the function **/
    cout << f1(3) << endl;
    cout << endl;


    /** an exception is thrown, but not caught **/
//    cout << f1(2) << endl;
    /** When an exception is thrown, the program will work its way up
    * the stack of function calls until it hits a catch() block.
    *
    * If no catch() block exists in the call stack, the program will quit.
    **/



    /** catching an exception of type int **/
//    try {
//        cout << f1(2) << endl;
//    } catch (int badValue) {
//        cerr << "Used a bad value: " << badValue << endl;
//        /** exception is caught, and program continues to execute **/
//    }


    /** catching a stdexcept exception **/
    try {
        cout << f1(2) << endl;

    } catch (invalid_argument &e) {
        cerr << "Message from invalid_argument: " << e.what() << endl;
        /** exception is caught, and program continues to execute **/
    }
    cout << endl;


    /** example of an out_of_range exception **/
    vector<int> myvector(10);

    try {
        cout << "Value is: " << myvector.at(20) << endl;

    } catch (out_of_range &e) {
        cerr << "Your index was out of range!" << endl;
    }


    /** catching multiple exception types **/
    try {
        cout << f1(1) << endl;

    } catch (invalid_argument &e) {
        cerr << "Message from invalid_argument: " << e.what() << endl;

    } catch (domain_error &e) {
        cerr << "Message from domain_error: " << e.what() << endl;

    } catch (...) {
        cerr << "Printed if the type thrown doesn't match";
        cerr << " any catch clauses" << endl;
    }


    /** rethrowing an exception **/
    try {
        cout << f1(1) << endl;

    } catch (domain_error &e) {
        throw;
        /** program will stop, if this exception is not caught **/
    }


    cout << "End of program." << endl;
    return 0;
}
