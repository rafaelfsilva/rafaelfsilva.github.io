// Standard Template Library example

#include <iostream>
#include <vector>
#include <list>
#include <algorithm>

using namespace std;

/**
 * Prints the elements of a vector using an iterator.
 *
 * @param v reference to the vector object
 * @param msg printing message
 */
void printVector(vector<int> &v, string msg) {
    cout << endl << msg << ": ";

    vector<int>::iterator vit;
    for (vit = v.begin(); vit != v.end(); vit++) { // O(n)
        cout << *vit << " "; // O(1)
    }
    cout << endl;
}

/**
 * Prints the elements of a list using an iterator.
 *
 * @param i reference to the list object
 * @param msg printing message
 */
void printList(list<int> &i, string msg) {
    cout << endl << msg << ": ";

    list<int>::iterator it;
    for (it = i.begin(); it != i.end(); it++) { // O(n)
        cout << *it << " "; // O(1)
    }
    cout << endl;
}

int main(int argc, char *argv[]) {

    // Vector Examples
    vector<int> myVector;

    myVector.push_back(3);
    myVector.push_back(9);
    myVector.push_back(5);
    myVector.push_back(1);
    myVector.push_back(7);

    cout << "Vector: ";
    for (int i = 0; i < myVector.size(); i++) { // O(n)
        cout << myVector[i] << " "; // O(1)
    }
    cout << endl;


    // LinkedList Examples
    list<int> myList;

    myList.push_back(5);
    myList.push_front(3);
    myList.insert(++myList.begin(), 9); // iterator to the first element of the list
    myList.push_back(7);
    myList.insert(--myList.end(), 1); // iterator to the end of the list

//    ATTENTION: Loop by index (not efficient, thus not allowed): O(n^2)
//    for (int i = 0; i < myList.size(); i++) { // O(n)
//        cout << myList.get(i) << endl; // O(n)
//    }

    // Iteration
    printList(myList, "List");

    // Reverse Iterator
    list<int>::reverse_iterator rit;

    cout << endl << "Reversed List: ";
    for (rit = myList.rbegin(); rit != myList.rend(); rit++) { // O(n)
        cout << *rit << " "; // O(1)
    }
    cout << endl;


    // Sort
    myList.sort();
    printList(myList, "Sorted List");



    vector<int> myVector2 = myVector; // copy assignment operator

    // Sort elements from the vector (Random Access Iterators)
    sort(myVector2.begin(), myVector2.end());
    printVector(myVector2, "Sorted Vector");

    // Sort only some elements from the vector (Random Access Iterators)
    sort(myVector.begin() + 1, myVector.end() - 1);
    printVector(myVector, "Partly Sorted Vector");



    // Count
    myVector.push_back(1);

    int myCount = count(myVector.begin(), myVector.end(), 1);
    cout << endl << "Vector: 1 appears " << myCount << " times." << endl;

    myCount = count(myVector.begin(), --myVector.end(), 1);
    cout << endl << "Vector: 1 appears " << myCount << " time." << endl;

    // Count for list
    myCount = count(myList.begin(), myList.end(), 9);
    cout << endl << "List: 9 appears " << myCount << " time." << endl;
}