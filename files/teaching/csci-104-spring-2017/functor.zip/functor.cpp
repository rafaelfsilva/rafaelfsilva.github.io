#include <iostream>
#include <map>
#include <vector>

class FunctorExample {
public:
    FunctorExample() {}

    FunctorExample(int x, std::string s) : x(x), s(s) {}

    int getX() const { return x; }

    void operator()() {
        std::cout << "I'm a functor!";
        std::cout << std::endl;
    }

    int operator()(int &x) {
        return ++x;
    }

private:
    int x;
    std::string s;
};


// Comparator for Maps
struct Comparator {
    bool operator()(const FunctorExample &lhs, const FunctorExample &rhs) const {
        return lhs.getX() < rhs.getX();
    }
};


template<typename InputIterator, typename Cond>
int count_if_local(InputIterator first, InputIterator last, Cond pred) {
    int ret = 0;
    for (; first != last; ++first) {
        if (pred(*first))
            ++ret;
    }
    return ret;
}

// Compartor for count_if
struct NegCond {
    bool operator()(const int val) const {
        return val < 0;
    }
};

int main() {
    FunctorExample a;

    int y = 5;
    std::cout << y << std::endl;

    // This does make sense!!
    a();
    // prints "I'm a functor!"

    // This also makes sense !!
    a(y);
    // y is now 6

    std::cout << y << std::endl;
    std::cout << std::endl;


    // More uses: Maps
//    std::map<FunctorExample, double> mm;
//    FunctorExample a2(5, "hi");
//    mm[a2] = 6.7;

    // Maps/sets require the key to have a 'less-than' operator
    // Functors help to solve this problem


    std::map<FunctorExample, double, Comparator> mm2;
    FunctorExample a3(5, "hi");
    mm2[a3] = 6.7;
    std::cout << "mm2[a3]: " << mm2[a3] << std::endl;
    std::cout << std::endl;


    // More uses: Vectors
    std::vector<int> myvec;

    // myvector: -5 -4 -3 -2 -1 0 1 2 3 4
    for (int i = -5; i < 5; i++)
        myvec.push_back(i);

    NegCond c;
    int mycnt = count_if_local(myvec.begin(), myvec.end(), c);
    std::cout << "myvec contains " << mycnt << " negative values." << std::endl;

    return 0;
}
