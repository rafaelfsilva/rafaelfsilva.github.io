#ifndef STR_H
#define STR_H

#include <iostream>

class Str {
public:
    Str();

    Str(const char *s);

    ~Str();

    size_t size() const;

    bool operator==(Str &s) const;

    const char &operator[](int index) const;

    char &operator[](int index);

    Str operator+(const Str &s) const;

    Str operator+(const char *s) const;

    friend std::ostream &operator<<(std::ostream &os, const Str &s);


private:
    char _data[20];
    // const char* _data;
};

#endif
