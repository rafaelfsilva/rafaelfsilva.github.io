#include <iostream>
#include "str.h"

using namespace std;

void dummyFunc(Str s) {
    char c = s[0];
    cout << "In dummy func, 1st char is " << c << endl;
}

int main() {
    const Str s1("hello ");
    Str s2("world");
    Str s4("world");

    cout << (s1 == s2) << endl;
    cout << (s4 == s4) << endl;
    cout << endl;

    dummyFunc(s2);
    cout << endl;

    cout << "s1[1]=" << s1[1] << endl;
    cout << endl;

    s2[0] = 'J';
    cout << "s2[0]=" << s2[0] << endl;

    cout << "s1 is " << s1 << endl;
    cout << "s2 is " << s2 << endl;

    cout << "s1+s2 = " << s1 + s2 << endl;

    cout << "s1+string = " << s1 + " - Some Value" << endl;

    return 0;
}
