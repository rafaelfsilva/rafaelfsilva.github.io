#include <iostream>
#include <cstring>
#include <stdexcept>
#include "str.h"

using namespace std;

Str::Str() {

}

Str::Str(const char *s) {
    strcpy(_data, s);
    // _data = s;
}

Str::~Str() {
}

size_t Str::size() const {
    return strlen(_data);
}

bool Str::operator==(Str &s) const {
    return _data == s._data;
}

const char &Str::operator[](int index) const {
    return _data[index];
}

char &Str::operator[](int index) {
   return _data[index];
}

Str Str::operator+(const Str &s) const {
   Str temp;
   strcpy(temp._data, _data);
   strcat(temp._data, s._data);
   return temp;
}

Str Str::operator+(const char *s) const {
   Str temp;
   strcpy(temp._data, _data);
   strcat(temp._data, s);
   return temp;
}

std::ostream &operator<<(std::ostream &os, const Str &s) {
    os << s._data;
    return os;
}
