/**
 * Consider a video game with a heroine who has a score and fights 3
 * different types of monsters {A, B, C}
 *
 * Upon slaying a monster you get a different point value:
 *   - 10 pts. = monster A
 *   - 20 pts. = monster B
 *   - 30 pts. = monster C
 *
 * You can check if you've slayed a monster via an 'isDead()' call on
 * a monster and then get the value to be added to the heroine's score
 * via 'getScore()'
 *
 * The game keeps objects for the heroine and the monsters
 *
 * How would you organize your Monster class(es) and its data members?
 */

#include <iostream>
#include <stdlib.h>
#include <time.h>

class Player {
public:
    Player() : score(0) {}

    void addToScore(int val) { score += val; }

    int getScore() { return score; }

private:
    int score;
};


class Monster {
public:
    Monster() {}

    bool isDead() {
        return rand() % 2 == 1;
    }

    virtual int getValue() = 0;

    virtual std::string getName() = 0;
};

class MonsterA : public Monster {
public:
    int getValue() {
        return 10;
    }

    std::string getName() {
        return "Monster A";
    }
};

class MonsterB : public Monster {
public:
    int getValue() {
        return 20;
    }

    std::string getName() {
        return "Monster B";
    }
};

class MonsterC : public Monster {
public:
    int getValue() {
        return 30;
    }

    std::string getName() {
        return "Monster C";
    }
};

int main() {
    // initialize random
    srand(time(NULL));

    Player p;
    int numMonsters = 10;

    Monster **monsters = new Monster *[numMonsters];

    for (int i = 0; i < numMonsters; i++) {
        int randomval = rand() % 3;

        if (randomval == 0) {
            monsters[i] = new MonsterA();
        } else if (randomval == 1) {
            monsters[i] = new MonsterB();
        } else {
            monsters[i] = new MonsterC();
        }
    }

    // Player action occurs here
    for (int i = 0; i < numMonsters; i++) {
        if (monsters[i]->isDead()) {
            std::cout << "Scored: " << monsters[i]->getName() << " = " << monsters[i]->getValue() << std::endl;
            p.addToScore(monsters[i]->getValue());
        } else {
            std::cout << "No Score: " << monsters[i]->getName() << std::endl;
        }
    }

    std::cout << std::endl;
    std::cout << "Player Score: " << p.getScore() << std::endl;
};
