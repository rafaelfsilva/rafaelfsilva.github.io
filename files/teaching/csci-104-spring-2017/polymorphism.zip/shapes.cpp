#include <iostream>
#include <cmath>
#include <vector>
#include <string>

using namespace std;

class Shape {
public:
    virtual ~Shape() {}

    virtual double getArea() = 0;

    virtual double getPerimeter() = 0;

    virtual string getType() = 0;
};


class RightTriangle : public Shape {
public:
    RightTriangle(double b, double h) : b(b), h(h) {}

    ~RightTriangle() {}

    double getArea() { return 0.5 * b * h; }

    double getPerimeter() { return sqrt(b * b + h * h) + h + b; }

    string getType() { return "Right Triangle"; }

private:
    double b, h;
};

class Circle : public Shape {
public:
    Circle(double r) : r(r) {}

    ~Circle() {}

    double getArea() { return 3.1416 * r * r; }

    double getPerimeter() { return 2 * 3.1416 * r; }

    string getType() { return "Circle"; }

private:
    double r;
};

class Rectangle : public Shape {
public:
    Rectangle(double l, double w) : l(l), w(w) {}

    ~Rectangle() {}

    double getArea() { return l * w; }

    double getPerimeter() { return 2 * (l + w); }

    string getType() { return "Rectangle"; }

private:
    double l, w;
};

class Square : public Rectangle {
public:
    Square(double s) : Rectangle(s, s), s(s) {}

    ~Square() {}

    string getType() { return "Square"; }

private:
    double s;
};


int main() {

    // Cannot instantiate shape, since it is an abstract class (interface)
    // Shape *shape = Shape();

    // creating a vector of shapes
    vector<Shape *> shapeList;

    Shape *rightTriangle = new RightTriangle(3, 4);
    shapeList.push_back(rightTriangle);

    Shape *rectangle = new Rectangle(3, 4);
    shapeList.push_back(rectangle);

    Rectangle *rectangle2 = new Rectangle(3, 4);

    // The call below is not allowed since 'rectangle2' is not a 'Shape' (base-class) pointer:
    // shapeList.push_back(rectangle2);
    //
    // To solve this problem, just assign the variable to a new variable of type Shape*:
    Shape *rectangle2_shape = rectangle2;
    shapeList.push_back(rectangle2_shape);

    // The call below is perfectly acceptable:
    shapeList.push_back(new Rectangle(5, 6));

    Square *square = new Square(4);
    Rectangle *rectangle3 = square;

    // Again, these are invalid calls:
    // shapeList.push_back(square);
    // shapeList.push_back(rectangle3);

    Shape *square_shape = square;
    shapeList.push_back(square_shape);

    shapeList.push_back(new Circle(2));


    // printing shapes
    for (vector<Shape *>::iterator it = shapeList.begin(); it != shapeList.end(); ++it) {
        Shape *s = *it;
        cout << s->getType() << ": Area=" << s->getArea() << " Perim=" << s->getPerimeter() << endl;
        delete s;
    }
    return 0;
}