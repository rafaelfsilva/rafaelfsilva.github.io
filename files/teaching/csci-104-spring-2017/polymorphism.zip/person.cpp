#include <iostream>
#include <vector>
#include <string>

class Person {
public:
    // accessible to anyone
    Person() {}

    Person(std::string name, int id) : name(name), id(id) {}

    virtual ~Person() { std::cout << "    Person destructor" << std::endl; }

    std::string get_name() { return name; }

    virtual void print() { std::cout << "  Name: " << name << "\tID: " << id << std::endl; }

private:
    // inaccessible to derived classes
    int id;

protected:
    // Private to anyone not inheriting from the base, and derived classes can access directly
    std::string name;
};

class Student : public Person {
public:
    Student() {}

    Student(std::string name, int id) : Person(name, id) {}

    ~Student() { std::cout << "    Student destructor" << std::endl; }

    void add_grade(int score) { grades.push_back(score); }

    int get_grade(int index) { return grades[index]; }

    void print_grades() {
        std::cout << "  Grades for " << name << ":" << std::endl;
        std::cout << "    ";
        for (size_t i = 0; i < grades.size(); i++) {
            std::cout << grades[i] << " ";
        }
        std::cout << std::endl;
    }

    void print() {
        if (grades.size() > 0) {
            std::cout << "  Name: " << name << "\tGRADE[0]: " << grades[0] << std::endl;
        } else {
            Person::print();
        }
    }

private:
    std::vector<int> grades;
};


class Faculty : private Person {
// public & protected base class members are private to clients (not accessible to the outside world)

public:
    Faculty() {}

    Faculty(std::string name, int id, bool tenure) : Person(name, id), tenure(tenure) {}

    ~Faculty() {}

    bool get_tenure() { return tenure; }

    void print() {
        if (tenure) {
            std::cout << "  Name: " << name << " (Tenure) " << std::endl;
        } else {
            Person::print();
        }
    }

private:
    bool tenure;
};


int main() {

    // Attention: do not initialize as 'Person p1("Mark", 10)', since it will not return a pointer to the object.
    Person *p1 = new Person("Mark", 10);
    Student *s1 = new Student("Tommy", 90);
    Faculty *f1 = new Faculty("Gaurav", 100, true);

    s1->add_grade(80);
    s1->add_grade(100);



    // Assignment of Base/Declared
    Person *p_s1 = s1;

    // Cannot assign a base class to a derived class
    // Student s_p1 = p1;



    // Derived class is no longer type compatible with the base class
    // Person p_f1 = f1;
    //
    // Can't have a base class pointer reference a derived object




    // static vs dynamic binding
    std::cout << "Static vs Dynamic Binding" << std::endl;
    s1->print();
    p_s1->print();
    //  check the use of adding/removing 'virtual' from void print()

    std::cout << std::endl;




    // virtual destructors
    std::cout << "Virtual Destructors" << std::endl;
    std::cout << "  Deleting p_s1:" << std::endl;
    delete p_s1;
    // check the use of adding/removing 'virtual' from ~Person()

    return 0;
}