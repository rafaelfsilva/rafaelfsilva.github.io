#include <iostream>

/**
 * A node of an AVL Tree
 */
class AVLNode {
public:
	AVLNode(int value) : value(value), parent(NULL), left(NULL), right(NULL), balance(0) {}

	int value;
	AVLNode *parent;
	AVLNode *left;
	AVLNode *right;
	int balance;
};

/**
 * The AVL Tree class
 */
class AVLTree {
public:
	AVLTree() : root(NULL) {}

	void insert(const int value) {
		AVLNode *new_node = new AVLNode(value);

		if (root == NULL) {
			root = new_node;
			return;
		}

		AVLNode *parent = NULL;
		AVLNode *next = root;

		while (true) {
			parent = next;
			if (value < parent->value) {
				if (parent->left == NULL) {
					parent->left = new_node;
					new_node->parent = parent;
					break;
				}
				next = parent->left;
			} else {
				if (parent->right == NULL) {
					parent->right = new_node;
					new_node->parent = parent;
					break;
				}
				next = parent->right;
			}
		}
		// update balance from parent
		if (parent->balance == -1 || parent->balance == 1) {
			parent->balance = 0;

		} else {
			if (parent->left == new_node) {
				parent->balance = -1;
			} else {
				parent->balance = 1;
			}
			insertFix(parent, new_node);
		}
	}

	void remove(const int value) {
		// find the node in the BST
		AVLNode *node = find(value);

		if (node == NULL) {
			return;  // the value is not in the BST
		}

		if (node->left != NULL && node->right != NULL) {
			// find in-order successor
			AVLNode *successor = getSuccessor(node);
			// swap node with in-order successor
			int temp_value = successor->value;
			successor->value = node->value;
			node->value = temp_value;
			std::swap(node, successor);
		}

		// find child node (left or right)
		AVLNode *child = node->left;
		if (node->right != NULL) {
			child = node->right;
		}

		// update parents (including root)
		AVLNode *parent = node->parent;
		if (child != NULL) {
			child->parent = parent;
		}

		int diff;
		if (parent == NULL) {
			root = child;
		} else {
			// If n is not in the root position determine its relationship with its parent
			if (node == parent->left) {
				parent->left = child;
				diff = 1;
			} else {
				parent->right = child;
				diff = -1;
			}
		}

		// delete node
		delete node;

		removeFix(parent, diff);
	}

	/**
	 * Print an AVL Tree in-order traversal
	 */
	void printInOrder() const {
		std::cout << "ROOT Node: " << root->value << std::endl;
		printInOrderHelper(root);
	}

private:
	AVLNode *root;

	void insertFix(AVLNode *parent, AVLNode *child) {
		// parent and grandparent should not be NULL
		if (parent == NULL || parent->parent == NULL) {
			return;
		}

		AVLNode *grandparent = parent->parent;

		if (parent == grandparent->left) { // left child of grandparent
			grandparent->balance += -1;

			if (grandparent->balance == 0) {
				return; // nothing to do, it is already balanced
			}

			if (grandparent->balance == -1) {
				insertFix(grandparent, parent);
				return;
			}

			// grandparent balance is -2
			if (child == parent->left) { // zig-zig - only 1 rotation
				rotateRight(grandparent, parent);
				parent->balance = 0;
				grandparent->balance = 0;

			} else { // zig-zag - 2 rotations
				rotateLeft(parent, child);
				rotateRight(grandparent, child);

				if (child->balance == -1) {
					parent->balance = 0;
					grandparent->balance = 1;

				} else if (child->balance == 0) {
					parent->balance = 0;
					grandparent->balance = 0;

				} else {
					parent->balance = -1;
					grandparent->balance = 0;
				}
				child->balance = 0;
			}

		} else { // right child of grandparent
			grandparent->balance += 1;

			if (grandparent->balance == 0) {
				return; // nothing to do, it is already balanced
			}

			if (grandparent->balance == 1) {
				insertFix(grandparent, parent);
				return;
			}

			// grandparent balance is 2
			if (child == parent->right) { // zig-zig - only 1 rotation
				rotateLeft(grandparent, parent);
				parent->balance = 0;
				grandparent->balance = 0;

			} else { // zig-zag - 2 rotations
				rotateRight(parent, child);
				rotateLeft(grandparent, child);

				if (child->balance == 1) {
					parent->balance = 0;
					grandparent->balance = -1;

				} else if (child->balance == 0) {
					parent->balance = 0;
					grandparent->balance = 0;

				} else {
					parent->balance = 1;
					grandparent->balance = 0;
				}
				child->balance = 0;
			}
		}
	}

	void removeFix(AVLNode *node, int diff) {
		// node should not be null
		if (node == NULL) {
			return;
		}

		// Let ndiff = +1 if n is a left child and -1 otherwise
		AVLNode *parent = node->parent;
		int ndiff = -1;
		if (parent != NULL && node == parent->left) {
			ndiff = 1;
		}

		if (node->balance == -1 && diff == -1) { // balance(n) + diff == -2
			AVLNode *child = node->left;
			if (child->balance <= 0) { // zig-zig case
				rotateRight(node, child);

				if (child->balance == -1) {
					node->balance = child->balance = 0;
					removeFix(parent, ndiff);

				} else { // balance == 0
					node->balance = -1;
					child->balance = 1;
				}

			} else { // zig-zag case
				AVLNode *grandchild = child->right;
				rotateLeft(child, grandchild);
				rotateRight(node, grandchild);

				if (grandchild->balance == 1) {
					node->balance = 0;
					child->balance = -1;

				} else if (grandchild->balance == 0) {
					node->balance = child->balance = 0;

				} else {
					node->balance = 1;
					child->balance = 0;
				}
				grandchild->balance = 0;
				removeFix(parent, ndiff);
			}

		} else if (node->balance == 1 && diff == 1) { // balance(n) + diff == +2
			AVLNode *child = node->right;
			if (child->balance >= 0) { // zig-zig case
				rotateLeft(node, child);

				if (child->balance == 1) {
					node->balance = child->balance = 0;
					removeFix(parent, ndiff);

				} else { // balance == 0
					node->balance = 1;
					child->balance = -1;
				}

			} else { // zig-zag case
				AVLNode *grandchild = child->left;
				rotateRight(child, grandchild);
				rotateLeft(node, grandchild);

				if (grandchild->balance == -1) {
					node->balance = 0;
					child->balance = 1;

				} else if (grandchild->balance == 0) {
					node->balance = child->balance = 0;

				} else {
					node->balance = -1;
					child->balance = 0;
				}
				grandchild->balance = 0;
				removeFix(parent, ndiff);
			}

		} else {
			if (node->balance == 0) {
				node->balance += diff;
				return;

			} else {
				node->balance = 0;
			}
			removeFix(parent, ndiff);
		}
	}

	/**
	 * Helper function to rotate to the left
	 */
	void rotateLeft(AVLNode *parent, AVLNode *child) {
		rotate(parent, child, true);
	}

	/**
	 * Helper function to rotate to the right
	 */
	void rotateRight(AVLNode *parent, AVLNode *child) {
		rotate(parent, child, false);
	}

	void rotate(AVLNode *parent, AVLNode *child, const bool left) {

		if (parent->parent == NULL) {
			root = child;

		} else {
			if (parent == parent->parent->left) { // left child
				parent->parent->left = child;
			} else { // right child
				parent->parent->right = child;
			}
		}

		// swapping parent and child
		child->parent = parent->parent;
		parent->parent = child;

		if (left) { // rotate left
			parent->right = child->left;
			if (child->left != NULL) {
				child->left->parent = parent;
			}
			child->left = parent;

		} else { // rotate right
			parent->left = child->right;
			if (child->right != NULL) {
				child->right->parent = parent;
			}
			child->right = parent;
		}
	}

	/**
	 * Find a node in a Binary Search Tree
	 */
	AVLNode *find(const int value) {
		AVLNode *node = root;

		while (node) {
			if (node->value == value) {
				return node;
			}
			if (value < node->value) {
				node = node->left;
			} else {
				node = node->right;
			}
		}
		return NULL;
	}

	/**
	 * Get in-order successor of a node
	 */
	AVLNode *getSuccessor(AVLNode *node) {
		// If right child exists, successor is the left most node of the right subtree
		if (node->right != NULL) {
			node = node->right;
			while (node->left != NULL) {
				node = node->left;
			}
			return node;
		}

		// Else walk up the ancestor chain until you traverse the first left child
		// pointer (find the first node who is a left child of his parent...
		// that parent is the successor)
		AVLNode *parent = node->parent;
		while (parent != NULL && node == parent->right) {
			node = parent;
			parent = parent->parent;
		}
		return parent;
	}

	void printInOrderHelper(const AVLNode *node) const {
		if (node == NULL) {
			return;
		}
		printInOrderHelper(node->left);
		std::cout << "Value: " << node->value << " - Balance: " << node->balance << std::endl;
		printInOrderHelper(node->right);
	}
};

int main() {
	// Insert Example
	AVLTree avl_tree;

	avl_tree.insert(10);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(20);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(30);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(15);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(25);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(12);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(5);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(3);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.insert(8);
	avl_tree.printInOrder();
	std::cout << std::endl;

	// Remove Example
	std::cout << "===== REMOVE EXAMPLE =====" << std::endl;
	avl_tree.remove(15);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.remove(3);
	avl_tree.printInOrder();
	std::cout << std::endl;

	avl_tree.remove(25);
	avl_tree.printInOrder();
	std::cout << std::endl;


	// New Tree
	std::cout << "===== ANOTHER TREE =====" << std::endl;
	AVLTree avl_tree2;
	avl_tree2.insert(20);
	avl_tree2.insert(10);
	avl_tree2.insert(30);
	avl_tree2.insert(8);
	avl_tree2.insert(15);
	avl_tree2.insert(25);
	avl_tree2.insert(35);
	avl_tree2.insert(5);
	avl_tree2.insert(12);
	avl_tree2.insert(17);
	avl_tree2.insert(28);
	avl_tree2.insert(14);
	avl_tree2.printInOrder();
	std::cout << std::endl;

	avl_tree2.remove(8);
	avl_tree2.printInOrder();
	std::cout << std::endl;
}