#ifndef COMPLEX_H
#define COMPLEX_H

#include <iostream>

class Complex {
public:
    Complex();

    Complex(double r, double i);

    // copy constructor
    Complex(const Complex &rhs);

    // copy assignment operator
    Complex &operator=(const Complex &rhs);

    Complex &operator=(const int r);

    double getReal() const { return _real; }

    double getImag() const { return _imag; }

    Complex add(const Complex &rhs) const;

    Complex operator+(const Complex &rhs) const;

    bool operator==(const Complex &rhs) const;

    friend std::ostream &operator<<(std::ostream &os, const Complex &rhs);

private:
    double _real;
    double _imag;
};

#endif
