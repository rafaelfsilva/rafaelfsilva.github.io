#include <iostream>
#include "complex.h"
#include <sstream>

using namespace std;

void compare(Complex &c1, Complex &c2) {
    if (c1 == c2) {
        cout << "EQUALS" << endl;
    } else {
        cout << "NOT EQUALS" << endl;
    }
}

// ** Copy constructor called for pass-by-value
void dummy(Complex rhs) {
    cout << "In dummy" << endl;
}

int main() {
    Complex c1(2, 3);
    Complex c2(4, 5);

    Complex c3 = c1 + c2;
    cout << c3.getReal() << "+" << c3.getImag() << "j" << endl;

    compare(c1, c1);
    compare(c1, c2);
    cout << endl;

    cout << c1;
    cout << c2;
    cout << c3;
    cout << endl;

    // Copy constructor
    dummy(c2);
    cout << endl;

    // copy assignment operator
    Complex c4, c5;
    c5 = c4 = c3; // same as c5.operator=( c4.operator=(c3) );
    cout << c5;
    cout << c4;
    cout << endl;

    Complex c6;
    c6 = 2; // assignment operator overloading
    cout << c6;

    return 0;
}
