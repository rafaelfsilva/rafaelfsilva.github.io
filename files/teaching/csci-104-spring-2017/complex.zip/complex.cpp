#include "complex.h"
#include <iostream>

using namespace std;

Complex::Complex() {
    _real = 0;
    _imag = 0;
}

Complex::Complex(double r, double i) {
    _real = r;
    _imag = i;
}

// copy constructor
Complex::Complex(const Complex &c) {
    cout << "In copy constructor" << endl;
    _real = c._real;
    _imag = c._imag;
}

// copy assignment operator
Complex &Complex::operator=(const Complex &rhs) {
    cout << "In copy assisnment operator" << endl;
    _real = rhs._real;
    _imag = rhs._imag;
    return *this;
}

Complex &Complex::operator=(const int r) {
    _real = r;
    _imag = 0;
    return *this;
}

Complex Complex::add(const Complex &rhs) const {
    Complex temp;
    temp._real = _real + rhs._real;
    temp._imag = _imag + rhs._imag;
    return temp;
}

Complex Complex::operator+(const Complex &rhs) const {
    return add(rhs);
}

bool Complex::operator==(const Complex &rhs) const {
    return _real == rhs._real && _imag == rhs._imag;
}

std::ostream &operator<<(std::ostream &os, const Complex &rhs) {
    os << rhs._real << "+" << rhs._imag << "j" << endl;
    return os;
}
